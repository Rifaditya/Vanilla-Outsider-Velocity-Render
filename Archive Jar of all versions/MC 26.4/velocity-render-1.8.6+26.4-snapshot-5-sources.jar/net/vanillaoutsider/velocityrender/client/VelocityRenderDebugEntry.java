// Copyright (C) 2026 Dasik (Rifaditya) | GNU GPLv3
package net.vanillaoutsider.velocityrender.client;

import net.minecraft.client.core.registries.ClientRegistries;
import net.minecraft.client.gui.components.debug.DebugEntryCategory;
import net.minecraft.client.gui.components.debug.DebugScreenDisplayer;
import net.minecraft.client.gui.components.debug.DebugScreenEntry;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;
import org.jspecify.annotations.Nullable;

/**
 * Native Minecraft 26.4 DebugScreenEntry for Velocity Render background engine diagnostics.
 * Integrates into the native F3+F6 Debug Options Screen (DebugOptionsScreen) under SCREEN_TEXT category.
 */
public class VelocityRenderDebugEntry implements DebugScreenEntry {

    public static final Identifier ID = Identifier.fromNamespaceAndPath("velocity-render", "engine_metrics");
    public static final ResourceKey<DebugScreenEntry> KEY = ResourceKey.create(ClientRegistries.DEBUG_SCREEN_ENTRY, ID);

    @Override
    public void display(
            DebugScreenDisplayer displayer,
            @Nullable Level serverOrClientLevel,
            @Nullable LevelChunk clientChunk,
            @Nullable LevelChunk serverChunk
    ) {
        if (!ClientVelocityTracker.isF3DebugEnabled()) {
            return;
        }
        String cachedLine = ClientVelocityTracker.getCachedF3Line();
        if (cachedLine != null) {
            displayer.addPriorityLine(cachedLine);
        }
    }

    @Override
    public DebugEntryCategory category() {
        return DebugEntryCategory.SCREEN_TEXT;
    }

    @Override
    public boolean isAllowed(boolean reducedDebugInfo) {
        return !reducedDebugInfo;
    }
}
